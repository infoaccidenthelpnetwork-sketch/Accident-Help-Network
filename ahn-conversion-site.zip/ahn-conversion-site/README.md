# Accident Help Network — Landing Site

Ad-ready landing page with bold hooks, pain-point cards, testimonials, and UTM-aware headline. Replace endpoint in `script.js`.
